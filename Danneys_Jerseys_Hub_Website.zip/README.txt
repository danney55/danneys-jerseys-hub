# Danney's Jerseys Hub — free website starter

## Included
- Responsive black/gold online-shop design
- Product search, category filters and sorting
- Shopping cart with sizes and quantities
- Checkout form with delivery details
- Mobile Money payment instruction
- Order summary prepared as an email to `danielamankwaah553@icloud.com`
- Customer account stored locally in the browser
- Customer reviews stored locally in the browser
- Featured products and promotions
- Free static hosting ready

## Important
The product pictures in this starter are **sample jersey illustrations**, not photographs of your stock. Replace them with your actual jersey photos before advertising specific products.

The site is static, so it does not process Mobile Money automatically and does not provide secure multi-device customer accounts yet. Those features need a backend/payment integration. The website itself can still be hosted for free.

## Free hosting
### GitHub Pages
1. Create a free GitHub account.
2. Create a new public repository, e.g. `danneys-jerseys-hub`.
3. Upload `index.html`, `styles.css`, and `app.js`.
4. Open Settings → Pages.
5. Choose Deploy from branch → main → root.
6. GitHub will provide a free `github.io` website address.

### Netlify
1. Create a free Netlify account.
2. Choose Add new site → Deploy manually.
3. Drag the project folder into the upload area.
4. Netlify provides a free `netlify.app` address.

## Your details already added
Shop: Danney's Jerseys Hub
Slogan: Your favorite team's jersey, our priority.
Location: Dubai Kejetia / Effiduase
Phone/WhatsApp: 0542363398
Email: danielamankwaah553@icloud.com
Player Version: GH₵120
Lacoste: GH₵160
Delivery: Effiduase free; Kumasi free; other locations depend on location
Payment: Mobile Money
